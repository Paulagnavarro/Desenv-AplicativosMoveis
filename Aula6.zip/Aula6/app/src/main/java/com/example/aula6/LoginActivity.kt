package com.example.aula6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula6.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val EMAIL = "paula@gmail.com"
    private val SENHA = "senha"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)

        setContentView(binding.root)

        // ação de clique para o botão
        binding.btnEntrar.setOnClickListener {
          //  Toast.makeText(this, "TESTE", Toast.LENGTH_SHORT).show()
            validarCampos()
        }
    }

    private fun validarCampos(){
        if(binding.edtEmail.text.isEmpty() ||
                binding.edtSenha.text.isEmpty()){
            exibirToast("Preencha todos os campos")
        } else {
            var email = binding.edtEmail.text.toString().toInt()
            var senha = binding.edtSenha.text.toString()

            // validar email e senha
            if (email.equals(EMAIL) && senha.equals(SENHA)){

                // redirecionar para a mainActivity
                var intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                // "matar esta activity"
                finish()

            } else {
                exibirToast("Email ou senha inválidos")
                binding.edtEmail.text.clear()
                binding.edtSenha.text.clear()
            }
        }
    }

    private fun exibirToast(mensagem: String) {
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show()
    }
}