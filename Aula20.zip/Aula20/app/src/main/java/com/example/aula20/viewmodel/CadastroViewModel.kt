package com.example.aula20.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.aula20.services.model.Tarefa
import com.example.aula20.services.model.ValidarTarefas
import com.example.aula20.services.repository.TarefaRepository

class CadastroViewModel(application: Application) : AndroidViewModel(application) {

    // dado "vivo" que será observado pela CadastroActivity:
    private var txtToast = MutableLiveData<String>()
    // objeto responsável por qualquer validação das tarefas:
    private var validacao = ValidarTarefas()
    // objeto responsável por acessar banco de dados:
    private var tarefaRepository = TarefaRepository(application.applicationContext)

    fun getTxtToast() : LiveData<String> {
        return txtToast
    }

    // método que irá receber uma string, verificar se ela não está em branco e,
    // caso não esteja, tentará salvar um objeto 'tarefa' no bacno de dados.
    // ela retornará 'false' se a string recebida estiver em branco ou o ROOM não
    // conseguir salvar o objeto no banco de dados.
    // E retornará 'true' se o ROOM conseguir salvar com sucesso o objeto no BD
    fun salvarTarefa(nomeTarefa: String) : Boolean {

        // passo 1: verificar se a string recebida está em branco
        if (validacao.verificarCampoVazio(nomeTarefa)){
            // se retornar true, a string recebida da CadastroActivity está vazia
            // nesse caso:
            txtToast.value = "Informe o nome da tarefa!"
            return false // não conseguimos salvar a tarefa no banco de dados
        }

        // passo 2: se a string não está em branco, então podemos
        // criar um novo objeto do tipo Tarefa
        var tarefa = Tarefa(0, nomeTarefa)

        // Passo 3: tentar salvar no banco de dados este objeto tarefa
        if (!tarefaRepository.salvarTarefa(tarefa)){
            // se o não conseguiu salvar:
            txtToast.value = "Erro ao tentar salvar tarefa. Tente novamente mais tarde"
            return false // não conseguimos salvar a tarefa no banco de dados
        }

        // se a função acima salvarTarefa retornou true:
        txtToast.value = "Tarefa cadastrada com sucesso!"
        return true // conseguimos salvar a tarefa com sucesso no banco de dados!

    }
}