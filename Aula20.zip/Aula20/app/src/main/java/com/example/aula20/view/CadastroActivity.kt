package com.example.aula20.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.aula20.R
import com.example.aula20.databinding.ActivityCadastroBinding
import com.example.aula20.viewmodel.CadastroViewModel

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private lateinit var cadastroViewModel: CadastroViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // inicializar o cadastroViewModel
        cadastroViewModel = ViewModelProvider(this).get(CadastroViewModel::class.java)
        // setar observadores
        setObservers()

        // ação de clique do botão salvar
        binding.btnSalvar.setOnClickListener {

            var nomeTarefa = binding.edtNomeTarefa.text.toString()
            // tentar salvar a tarefa digitada no form no banco de dados

            if(cadastroViewModel.salvarTarefa(nomeTarefa)){
                // se o cadastroViewModel conseguiu salvar a tarefa no BD.
                // nós não precisamos continuar nesta activity.
                // Então a finalizaremos e voltaremos para a MainActivity
                finish()
            }
        }

    }

    fun setObservers(){
        cadastroViewModel.getTxtToast().observe(this){
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }
    }
}