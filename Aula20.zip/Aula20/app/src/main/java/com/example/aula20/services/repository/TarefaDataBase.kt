package com.example.aula20.services.repository

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.aula20.services.model.Tarefa

@Database(entities = [Tarefa::class], version = 1)
abstract class TarefaDataBase : RoomDatabase() {

    abstract fun getDAO() : TarefaDAO

    companion object{

        private lateinit var INSTANCE : TarefaDataBase

        fun getInstance(context: Context) : TarefaDataBase {

            if (!Companion::INSTANCE.isInitialized) {
                INSTANCE = Room.databaseBuilder(context, TarefaDataBase::class.java, "tarefas_db")
                    .allowMainThreadQueries()
                    .build()
            }

            return INSTANCE
        }


    }

}