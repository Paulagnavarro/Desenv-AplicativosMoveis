package com.example.aula20.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.aula20.R
import com.example.aula20.services.model.Tarefa
import com.example.aula20.view.viewholder.TarefaViewHolder

class TarefaAdapter(var context: Context) : RecyclerView.Adapter<TarefaViewHolder>() {

    lateinit var listaTarefas : List<Tarefa>

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TarefaViewHolder {
        val tarefaLayout = LayoutInflater.from(context)
            .inflate(R.layout.tarefa_layout, parent, false)

        var holder = TarefaViewHolder(tarefaLayout)

        return holder
    }

    override fun onBindViewHolder(holder: TarefaViewHolder, position: Int) {

        holder.txtNomeTarefa.text = listaTarefas[position].tarefa

    }

    override fun getItemCount(): Int {
        return listaTarefas.size
    }

    // método para atualizar a lista de tarefas local
    fun updateTarefas(list : List<Tarefa>){
        listaTarefas = list
        notifyDataSetChanged()
    }

}