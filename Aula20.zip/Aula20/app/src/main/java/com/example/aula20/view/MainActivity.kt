package com.example.aula20.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aula20.R
import com.example.aula20.databinding.ActivityMainBinding
import com.example.aula20.view.adapter.TarefaAdapter
import com.example.aula20.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: TarefaAdapter
    private lateinit var viewModel : MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // inicializar adapter
        adapter = TarefaAdapter(this)
        // Inicializar o view model
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        // setar o layour para a recycler view
        binding.rcvTarefas.layoutManager = LinearLayoutManager(this)

        setObservers() // seta observadores para o view model
        setAdapter() // seta e configura adapter

        binding.btnNovaTarefa.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
        }
    }

    fun setObservers(){
        viewModel.getListaTarefas().observe(this){
            adapter.updateTarefas(it)
        }
    }

    fun setAdapter(){
        // setar o adapter para a recycler view
        binding.rcvTarefas.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        // solicita ao view model que puxe os dados do banco de dados
        // para serem usados pelo adapter
        viewModel.getTarefasFromDB()
    }
}