package com.example.aula5

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.aula5.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    //criar uma referencia ao view binding desta classe
    private lateinit var  binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // inicializar o objeto binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        // acima estamos "inflando" o layout do activity_main.xml para dentro do objeto binding

        // setar o binding como layout desta classe
        var view = binding.root
        setContentView(view)

        // acessar os componentes TextView utilizando o view binding
        binding.txtBox1.text = "Texto do Box 1!"
        binding.txtBox2.text = "aula 05 de Android!"
        binding.txtBox3.text = "Este é o terceiro!"
        binding.txtBox4.text = "Hello There!"

        // configurar a ação de clique do botão
        binding.btnAbrir.setOnClickListener {
            // configurrar intent para acessar a segunda activity
            var intent = Intent(this, SegundaActivity::class.java)

            // iniciar SegundaActivity
            startActivity(intent)
        }
    }
}