package com.example.aula31

import androidx.appcompat.app.AppCompatActivity
import android.os.bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // buscar a referencia de componentes da view
        var txtMensagem = findViewById<TextView>(R.id.txtMensagem)
        var edtNome = findViewById<EditText>(R.id.edtNome)
        var btnCadastrar = findViewById<Button>(R.id.btnCadastrar)

        // criar variavel local
        var mensagem = "Aula 03 de Android"

        // atribui o valor desta variavel para o txtMensagem
        txtMensagem.text = mensagem

        // configurar a ação de clique do botão btnCadastrar
        btnCadastrar.setonclickListener {
            if (etdNome.text.isEmpty()){
                Toast.makeText(this, "Informe o nome antes: $nome", Toast.LENGTH_LONG).show()
            } else {
                var nome = edtNome.text.toString()
                // mostrar nome cadastrado dentro de um Toast
                Toast.makeText(this, "Nome cadastrado: $nome", Toast.LENGTH_LONG).show()

                // limpar o campo edtNome
                edtNome.text.clear() // edtNome.text ""
            }
        }
    }
}