package com.example.game.services.repository

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.game.services.model.Heroi

@Database(entities = [Heroi::class], version = 1)
abstract class HeroiDataBase : RoomDatabase() {

    abstract fun getDAO() : HeroiDAO

    companion object{

        private lateinit var INSTANCE : HeroiDataBase

        fun getInstance(context: Context) : HeroiDataBase {

            if (!Companion::INSTANCE.isInitialized) {
                INSTANCE = Room.databaseBuilder(context, HeroiDataBase::class.java, "herois_db")
                    .allowMainThreadQueries()
                    .build()
            }
            return INSTANCE
        }
    }
}