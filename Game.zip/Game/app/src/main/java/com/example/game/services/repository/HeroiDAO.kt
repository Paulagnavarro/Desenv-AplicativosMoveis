package com.example.game.services.repository

import androidx.room.*
import com.example.game.services.model.Heroi

@Dao
interface HeroiDAO {

    @Insert
    fun salvarHeroi(heroi: Heroi) : Long

    @Delete
    fun excluirHeroi(heroi: Heroi)

    @Update
    fun atualizarHeroi(heroi: Heroi)

    @Query("SELECT * FROM herois WHERE id = :id")
    fun getHerois(id: Int) : Heroi

    @Query("SELECT * FROM herois")
    fun getHerois() : List<Heroi>

}