package com.example.game.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.game.R

class HeroiActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_heroi)
    }
}