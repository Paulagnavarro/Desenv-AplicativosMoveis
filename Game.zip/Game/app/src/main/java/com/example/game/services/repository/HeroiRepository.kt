package com.example.game.services.repository

import android.content.Context
import com.example.game.services.model.Heroi

class HeroiRepository(var context: Context) {

    private val DAO = HeroiDataBase.getInstance(context).getDAO()

    fun salvarHeroi(heroi: Heroi) : Boolean {
        return DAO.salvarHeroi(heroi) > 0
    }

    fun excluirHeroi(heroi: Heroi){
        DAO.excluirHeroi(heroi)
    }

    fun atualizarHeroi(heroi: Heroi) {
        DAO.atualizarHeroi(heroi)
    }

    fun getHeroi(id: Int) : Heroi {
        return DAO.getHerois(id)
    }

    fun getHerois(): List<Heroi> {
        return DAO.getHerois()
    }
}