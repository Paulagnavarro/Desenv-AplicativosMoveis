package com.example.game.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.game.services.model.Heroi
import com.example.game.services.repository.HeroiRepository

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private var listaHerois = MutableLiveData<List<Heroi>>()
    private var repository = HeroiRepository(application.applicationContext)
    private var txtToast = MutableLiveData<String>()

    fun getListaHerois() : LiveData<List<Heroi>> {
        return listaHerois
    }

    fun getTxtToast() : LiveData<String> {
        return txtToast
    }

    fun getHeroisFromDB(){
        listaHerois.value = repository.getHerois()
    }

    fun excluirHeroi(heroi: Heroi) {
        repository.excluirHeroi(heroi)
        txtToast.value = "Heroi excluído"
    }

}