package com.example.game.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.game.R
import com.example.game.databinding.ActivityCadastroBinding
import com.example.game.services.model.Heroi
import com.example.game.viewmodel.CadastroViewModel

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private lateinit var cadastroViewModel: CadastroViewModel
    private lateinit var heroiFromDB : Heroi
    private var idHeroi : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cadastroViewModel = ViewModelProvider(this).get(CadastroViewModel::class.java)

        setObservers()

        idHeroi = intent.getIntExtra("idTarefa", idHeroi)

        if (idHeroi > 0) {
            cadastroViewModel.findHeroi(idHeroi)
            binding.txtHeroi.text = "EDITAR HEROI"
        }

        binding.btnSalvar.setOnClickListener {

            var nomeHeroi = binding.edtNomeHeroi.text.toString()

            if(idHeroi > 0){ // tenta editar
                heroiFromDB.heroi = nomeHeroi

                if(cadastroViewModel.atualizarHeroi(heroiFromDB)){
                    finish()
                }

            } else if(cadastroViewModel.salvarHeroi(nomeHeroi)){
                finish()
            }
        }

    }
    fun setObservers(){
        cadastroViewModel.getTxtToast().observe(this){
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }

        cadastroViewModel.getHeroiFromDB().observe(this){
            heroiFromDB = it
            binding.edtNomeHeroi.setText(heroiFromDB.heroi)
        }

    }
}