package com.example.game.services.model

class ValidarHerois {

    fun verificarCampoVazio(nomeHeroi : String) : Boolean {
        return nomeHeroi.isEmpty()
    }

    fun verificarValorAtk(valorAtk : Int) : Boolean{
        return valorAtk >= 0
    }

    fun verificarValorDef(valorDef : Int) : Boolean{
        return valorDef >= 0
    }

}