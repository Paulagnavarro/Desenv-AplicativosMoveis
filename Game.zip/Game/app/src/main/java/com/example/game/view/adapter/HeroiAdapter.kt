package com.example.game.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.game.R
import com.example.game.services.model.Heroi
import com.example.game.view.viewholder.HeroiViewHolder


class HeroiAdapter(var context: Context) : RecyclerView.Adapter<HeroiViewHolder>() {

    lateinit var listaHerois : List<Heroi>
    var onItemLongClick : ((Int) -> Unit)? = null
    var onItemClick : ((Int) -> Unit)? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HeroiViewHolder {
        val heroiLayout = LayoutInflater.from(context)
            .inflate(R.layout.heroi_layout, parent, false)

        var holder = HeroiViewHolder(heroiLayout)

        return holder
    }

    override fun onBindViewHolder(holder: HeroiViewHolder, position: Int) {

        holder.txtNomeHeroi.text = listaHerois[position].heroi

        holder.itemView.setOnLongClickListener {
            onItemLongClick?.invoke(position)
            true
        }


        holder.itemView.setOnClickListener{
            onItemClick?.invoke(position)
        }

    }

    override fun getItemCount(): Int {
        return listaHerois.size
    }

    fun updateHerois(list : List<Heroi>){
        listaHerois = list
        notifyDataSetChanged()
    }

}