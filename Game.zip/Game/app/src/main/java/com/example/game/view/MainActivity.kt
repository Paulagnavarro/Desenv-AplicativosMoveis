package com.example.game.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.game.R
import com.example.game.databinding.ActivityMainBinding
import com.example.game.view.adapter.HeroiAdapter
import com.example.game.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: HeroiAdapter
    private lateinit var viewModel : MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = HeroiAdapter(this)

        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        binding.rcvHerois.layoutManager = LinearLayoutManager(this)

        setObservers()
        setAdapter()

        binding.btnNovoHeroi.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
        }
    }

    fun setObservers(){
        viewModel.getListaHerois().observe(this){
            adapter.updateHerois(it)
        }
        viewModel.getTxtToast().observe(this){
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }
    }

    fun setAdapter(){
        binding.rcvHerois.adapter = adapter

        adapter.onItemLongClick = {
            var heroiTemp = adapter.listaHerois[it]
            viewModel.excluirHeroi(heroiTemp)
            viewModel.getHeroisFromDB()
        }


        adapter.onItemClick = {
            var heroiTemp = adapter.listaHerois[it]
            var intent = Intent(this, CadastroActivity::class.java)
            intent.putExtra("idHeroi", heroiTemp.id)
            startActivity(intent)
        }

    }

    override fun onResume() {
        super.onResume()
        viewModel.getHeroisFromDB()
    }
}