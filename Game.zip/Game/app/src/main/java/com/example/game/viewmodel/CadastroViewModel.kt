package com.example.game.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.game.services.model.Heroi
import com.example.game.services.model.ValidarHerois
import com.example.game.services.repository.HeroiRepository


class CadastroViewModel(application: Application) : AndroidViewModel(application) {

    private var txtToast = MutableLiveData<String>()
    private var validacao = ValidarHerois()
    private var heroiRepository = HeroiRepository(application.applicationContext)
    private var heroiFromDB = MutableLiveData<Heroi>()

    fun getHeroiFromDB() : LiveData<Heroi> {
        return heroiFromDB
    }

    fun getTxtToast() : LiveData<String> {
        return txtToast
    }

    fun salvarHeroi(nomeHeroi: String) : Boolean {

        if (validacao.verificarCampoVazio(nomeHeroi)){
            txtToast.value = "Informe o nome do Heroi!"
            return false
        }

        var heroi = Heroi(0, nomeHeroi)

        if (!heroiRepository.salvarHeroi(heroi)){

            txtToast.value = "Erro ao tentar salvar heroi. Tente novamente mais tarde"
            return false
        }

        txtToast.value = "Heroi cadastrado com sucesso!"
        return true

    }

    fun findHeroi(id: Int) {
        heroiFromDB.value = heroiRepository.getHeroi(id)
    }

    fun atualizarHeroi(heroi: Heroi) : Boolean {

        if (validacao.verificarCampoVazio(heroi.heroi)){
            txtToast.value = "Informe o nome do heroi"
            return false
        }

        heroiRepository.atualizarHeroi(heroi)
        txtToast.value = "Heroi atualizado"
        return true
    }

}