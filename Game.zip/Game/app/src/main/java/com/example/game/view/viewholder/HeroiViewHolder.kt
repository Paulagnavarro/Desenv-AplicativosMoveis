package com.example.game.view.viewholder

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.game.R


class HeroiViewHolder(heroiLayout: View) : RecyclerView.ViewHolder(heroiLayout) {
    var txtNomeHeroi = heroiLayout.findViewById<TextView>(R.id.txtNomeHeroi)
}