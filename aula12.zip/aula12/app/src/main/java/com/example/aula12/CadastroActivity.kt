package com.example.aula12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula12.databinding.ActivityCadastroBinding

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCadastrar.setOnClickListener {
            validarDados()
        }
    }

    private fun validaDados(){
        if(binding.edtAno.text.isEmpty() ||
                binding.edtkm.text.isEmpty() ||
                binding.edtMarca.text.isEmpty()||
                binding.edtModleo.text.isEmpty() ||
                binding.edtCor.text.isEmpty() ||
                        binding.edtPlaca.text.isEmpty ) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT)
            return
        }

        var carro = Carro(binding.edtMarca.text.toString(),
        binding.edtModelo.text.toString(),
        binding.edtCor.text.toString(),
        binding.edtAno.text.toString().toInt(),
        binding.edtPlaca.text.toString(),
        binding.edtKm.text.toString().toFloat())

        ListaCarros.addCarro(carro)
        finish()
    }
}