package com.example.aula12

import java.text.FieldPosition

class ListaCarros private constructor() {

    companion object {
        private var listaCarros = mutableListOf<Carro>()

        init {
            listaCarros.add(Carro("Ford", "Fiesta", "Vermelho", 2014, "ABC-1234",
                95123.56f))
            listaCarros.add(Carro("Chevrolet", "Celta", "Preto", 2015, "ACB-65430",
            4567f))
        }

        // adicionar um carro
        fun addCarro(carro: Carro){
            listaCarros.add(carro)
        }

        // retornar um carro especifico
        fun getCarro(position: Int) : Carro{
            return listaCarros[position]
        }

        // remover um carro
        fun removeCarro(position: Int) {
            listaCarros.removeAt(position)
        }

        // retorna o tamanho da lista
        fun getListSize(): Int {
            return listaCarros.size
        }

    }
}