package com.example.aula12

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class CarroAdapter(var context: Context) : RecyclerView.Adapter<CarroViewHolder>(){

    // criando o viewHolder para atualizar os itens
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarroViewHolder {
        var layoutCarro = LayoutInflater.from(parent.context)
            .inflate(R.layout.layout_carro, parent, false)
        var carroViewHolder = CarroViewHolder(layoutCarro)
        return carroViewHolder
    }

    // montar cada iten da lista na tela
    override fun onBindViewHolder(holder: CarroViewHolder, position: Int) {
        var carro = ListaCarros.getCarro(position)
        holder.txtMarcaModelo.text = "${carro.marca} (${carro.modelo})"

        holder.txtMarcaModelo.setOnLongClickListener{
            // iniciar a detalhes activity mandando como parametro para a intent o valor
            // de "position" (que é a posição do elemento clicado na lista)
            var intent = Intent(context, DetalhesActivity::class.java)
            intent.putExtra("position", position)
            context.startActivity(intent)
            true
        }

    }

    // retorna o numero de elementos da lista
    override fun getItemCount(): Int {
        return ListaCarros.getListSize()
    }
}