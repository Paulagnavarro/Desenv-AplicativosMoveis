package com.example.aula12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.aula12.databinding.ActivityDetalhesBinding

class DetalhesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetalhesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetalhesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var position = intent.getIntExtra("position", -1)

        if(position == -1) {
            finish()
        }

        var carro = ListaCarros.getCarro(position)

        binding.txtModelo.text = carro.modelo
        binding.txtMarca.text = carro.marca
        binding.txtCor.text = carro.cor
        binding.txtAno.text = "Ano ${carro.ano}"  //carro.ano.toString()
        binding.txtPlaca.text = "Placa ${carro.placa}"
        binding.txtKm.text = "${carro.quilometragem} KM"

        // remove um carro da lista
        binding.btnExcluir.setOnClickListener {
            ListaCarros.removeCarro(position)
            finish()
        }
    }
}